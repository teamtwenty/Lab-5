//
//  Real.h
//  Lab 5
//
//  Created by Maxx Rodriguez on 4/22/14.
//  Copyright (c) 2014 Maxx Rodriguez. All rights reserved.
//

#ifndef __Lab_5__Real__
#define __Lab_5__Real__

#include <iostream>
#include "Literal.h"


class Real : public Literal<double>
{
private:
    
public:
    Real();
    virtual void print();
};
#endif /* defined(__Lab_5__Real__) */
